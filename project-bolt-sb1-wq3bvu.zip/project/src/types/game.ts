export interface Pipe {
  position: number;
  height: number;
  passed: boolean;
}

export interface GameState {
  birdPosition: number;
  birdVelocity: number;
  birdRotation: number;
  pipes: Pipe[];
  isGameOver: boolean;
  score: number;
  highScore: number;
}
import React, { useState } from 'react';
import { useScores } from '../hooks/useScores';

interface GameOverProps {
  score: number;
  highScore: number;
  onRestart: () => void;
}

export const GameOver: React.FC<GameOverProps> = ({ score, highScore, onRestart }) => {
  const [playerName, setPlayerName] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const { saveScore } = useScores();

  const handleSubmit = async () => {
    if (playerName.trim()) {
      await saveScore(playerName.trim(), score);
      setIsSubmitted(true);
    }
  };

  return (
    <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
      <div className="bg-white p-8 rounded-lg shadow-lg text-center">
        <h2 className="text-2xl font-bold mb-4">Game Over!</h2>
        <p className="mb-2">Score: {score}</p>
        <p className="mb-4">High Score: {highScore}</p>
        
        <button
          onClick={onRestart}
          className="w-full bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded mb-4 transition-colors"
        >
          Play Again
        </button>

        {!isSubmitted ? (
          <div className="space-y-2">
            <input
              type="text"
              placeholder="Enter your name"
              value={playerName}
              onChange={(e) => setPlayerName(e.target.value)}
              className="w-full px-3 py-2 border rounded-md text-sm"
              maxLength={20}
            />
            <button
              onClick={handleSubmit}
              className="w-full bg-yellow-400 hover:bg-yellow-500 text-white text-sm py-1.5 px-3 rounded transition-colors"
            >
              Submit Score
            </button>
          </div>
        ) : (
          <p className="text-green-500 text-sm">Score submitted!</p>
        )}
      </div>
    </div>
  );
}
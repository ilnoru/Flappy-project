import React, { useState, useEffect } from 'react';
import { Trophy } from 'lucide-react';
import { collection, query, orderBy, limit, getDocs } from 'firebase/firestore';
import { db } from '../config/firebase';

interface Score {
  playerName: string;
  score: number;
  timestamp: number;
}

export const Leaderboard: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scores, setScores] = useState<Score[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const fetchScores = async () => {
    setIsLoading(true);
    try {
      const q = query(
        collection(db, 'scores'),
        orderBy('score', 'desc'),
        limit(10)
      );
      const querySnapshot = await getDocs(q);
      const scoreData: Score[] = [];
      querySnapshot.forEach((doc) => {
        scoreData.push(doc.data() as Score);
      });
      setScores(scoreData);
    } catch (error) {
      console.error('Error fetching scores:', error);
    }
    setIsLoading(false);
  };

  useEffect(() => {
    if (isOpen) {
      fetchScores();
    }
  }, [isOpen]);

  return (
    <div className="absolute top-4 right-4" data-leaderboard>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="bg-yellow-400 hover:bg-yellow-500 text-white p-2 rounded-full shadow-lg transition-colors"
      >
        <Trophy size={24} />
      </button>

      {isOpen && (
        <div className="absolute top-12 right-0 bg-white rounded-lg shadow-xl p-4 w-64">
          <h2 className="text-xl font-bold mb-4 flex items-center">
            <Trophy size={20} className="mr-2 text-yellow-400" />
            Leaderboard
          </h2>
          
          {isLoading ? (
            <div className="text-center py-4">Loading...</div>
          ) : (
            <div className="space-y-2">
              {scores.map((score, index) => (
                <div
                  key={index}
                  className="flex justify-between items-center p-2 bg-gray-50 rounded"
                >
                  <div className="flex items-center">
                    <span className="font-bold mr-2">{index + 1}.</span>
                    <span>{score.playerName}</span>
                  </div>
                  <span className="font-bold">{score.score}</span>
                </div>
              ))}
              {scores.length === 0 && (
                <div className="text-center text-gray-500">No scores yet</div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
import React from 'react';

interface BirdProps {
  position: number;
  rotation: number;
}

export const Bird: React.FC<BirdProps> = ({ position }) => {
  return (
    <div
      className="absolute w-12 h-8 left-12"
      style={{
        top: `${position}px`,
        willChange: 'transform',
      }}
    >
      {/* Bird head - circular shape */}
      <div className="absolute w-8 h-8 bg-yellow-400 rounded-full">
        {/* Single eye */}
        <div className="absolute w-2.5 h-2.5 bg-white rounded-full top-2 left-2">
          <div className="absolute w-1.5 h-1.5 bg-black rounded-full top-0.5 left-0.5" />
        </div>
      </div>
      
      {/* Beak - now positioned outside the head circle */}
      <div className="absolute left-6 top-3">
        <div className="w-5 h-2.5 bg-orange-500" style={{ clipPath: 'polygon(0 0, 100% 50%, 0 100%)' }} />
      </div>
    </div>
  );
}
import React from 'react';

interface PipeProps {
  height: number;
  position: number;
  isTop: boolean;
}

export const Pipe: React.FC<PipeProps> = ({ height, position, isTop }) => {
  return (
    <div
      className="absolute w-16 bg-green-500 flex flex-col items-center"
      style={{
        height: `${height}px`,
        left: `${position}px`,
        top: isTop ? 0 : 'auto',
        bottom: isTop ? 'auto' : 0,
      }}
    >
      <div className={`w-20 h-8 bg-green-600 ${isTop ? 'mt-auto' : ''}`} />
    </div>
  );
}
import { useState, useEffect, useCallback } from 'react';
import { checkCollision } from '../utils/collisionDetection';
import type { Pipe, GameState } from '../types/game';
import {
  GRAVITY,
  JUMP_FORCE,
  PIPE_SPEED,
  PIPE_SPAWN_INTERVAL,
  GAP_SIZE,
  INITIAL_POSITION,
} from '../constants/gameSettings';

export const useGameLogic = () => {
  const [birdPosition, setBirdPosition] = useState(INITIAL_POSITION);
  const [birdVelocity, setBirdVelocity] = useState(0);
  const [birdRotation] = useState(0);
  const [pipes, setPipes] = useState<Pipe[]>([]);
  const [isGameOver, setIsGameOver] = useState(false);
  const [score, setScore] = useState(0);
  const [highScore, setHighScore] = useState(0);
  const [hasGameStarted, setHasGameStarted] = useState(false);

  const jump = useCallback(() => {
    if (!hasGameStarted) {
      setHasGameStarted(true);
    }
    if (!isGameOver) {
      setBirdVelocity(JUMP_FORCE);
    }
  }, [isGameOver, hasGameStarted]);

  const reset = useCallback(() => {
    setBirdPosition(INITIAL_POSITION);
    setBirdVelocity(0);
    setPipes([]);
    setIsGameOver(false);
    setScore(0);
    setHasGameStarted(false);
  }, []);

  useEffect(() => {
    if (isGameOver || !hasGameStarted) return;

    let lastTime = performance.now();
    const gameLoop = setInterval(() => {
      const currentTime = performance.now();
      const deltaTime = (currentTime - lastTime) / 16;
      lastTime = currentTime;

      setBirdPosition((prev) => {
        const newPosition = prev + birdVelocity * deltaTime;
        if (newPosition < 0 || newPosition > 500) {
          setIsGameOver(true);
          return prev;
        }
        return newPosition;
      });

      setBirdVelocity((prev) => prev + GRAVITY * deltaTime);

      setPipes((prevPipes) => {
        return prevPipes
          .map((pipe) => ({
            ...pipe,
            position: pipe.position - PIPE_SPEED * deltaTime,
          }))
          .filter((pipe) => pipe.position > -100);
      });
    }, 16);

    return () => clearInterval(gameLoop);
  }, [isGameOver, birdVelocity, hasGameStarted]);

  useEffect(() => {
    if (isGameOver || !hasGameStarted) return;

    const spawnPipe = setInterval(() => {
      const height = Math.random() * (300 - 100) + 100;
      setPipes((prev) => [
        ...prev,
        { position: 800, height, passed: false },
      ]);
    }, PIPE_SPAWN_INTERVAL);

    return () => clearInterval(spawnPipe);
  }, [isGameOver, hasGameStarted]);

  useEffect(() => {
    if (isGameOver || !hasGameStarted) return;

    if (checkCollision(birdPosition, pipes, GAP_SIZE)) {
      setIsGameOver(true);
      setHighScore((prev) => Math.max(prev, score));
      return;
    }

    pipes.forEach((pipe) => {
      if (!pipe.passed && pipe.position < 0) {
        pipe.passed = true;
        setScore((prev) => prev + 1);
      }
    });
  }, [pipes, birdPosition, isGameOver, score, hasGameStarted]);

  return {
    birdPosition,
    birdRotation,
    pipes,
    isGameOver,
    score,
    highScore,
    jump,
    reset,
    hasGameStarted,
  };
};
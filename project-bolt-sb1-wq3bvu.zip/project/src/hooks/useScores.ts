import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../config/firebase';

export const useScores = () => {
  const saveScore = async (playerName: string, score: number) => {
    try {
      await addDoc(collection(db, 'scores'), {
        playerName,
        score,
        timestamp: serverTimestamp(),
      });
    } catch (error) {
      console.error('Error saving score:', error);
    }
  };

  return { saveScore };
};
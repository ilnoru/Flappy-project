import React, { useEffect } from 'react';
import { Bird } from './components/Bird';
import { Pipe } from './components/Pipe';
import { GameOver } from './components/GameOver';
import { Leaderboard } from './components/Leaderboard';
import { useGameLogic } from './hooks/useGameLogic';

function App() {
  const {
    birdPosition,
    birdRotation,
    pipes,
    isGameOver,
    score,
    highScore,
    jump,
    reset,
    hasGameStarted,
  } = useGameLogic();

  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (e.code === 'Space') {
        jump();
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [jump]);

  const handleGameAreaClick = (e: React.MouseEvent) => {
    // Check if the click target is within the leaderboard component
    const isLeaderboardClick = (e.target as Element).closest('[data-leaderboard]');
    if (!isLeaderboardClick) {
      jump();
    }
  };

  return (
    <div 
      className="relative w-[800px] h-[500px] mx-auto mt-8 bg-sky-200 overflow-hidden cursor-pointer"
      onClick={handleGameAreaClick}
    >
      <div className="absolute bottom-0 w-full h-20 bg-green-400" />
      
      <Bird position={birdPosition} rotation={birdRotation} />
      
      {pipes.map((pipe, index) => (
        <React.Fragment key={index}>
          <Pipe
            height={pipe.height}
            position={pipe.position}
            isTop={true}
          />
          <Pipe
            height={500 - pipe.height - 150}
            position={pipe.position}
            isTop={false}
          />
        </React.Fragment>
      ))}

      <div className="absolute top-4 left-4 text-2xl font-bold text-white">
        Score: {score}
      </div>

      {!hasGameStarted && !isGameOver && (
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="bg-white/80 px-6 py-4 rounded-lg shadow-lg text-center">
            <p className="text-2xl font-bold text-gray-800">Press Space to Start</p>
          </div>
        </div>
      )}

      <Leaderboard />

      {isGameOver && (
        <GameOver
          score={score}
          highScore={highScore}
          onRestart={reset}
        />
      )}
    </div>
  );
}

export default App;
export const GRAVITY = 0.5;
export const JUMP_FORCE = -8;
export const PIPE_SPEED = 3;
export const PIPE_SPAWN_INTERVAL = 1200;
export const GAP_SIZE = 150;
export const INITIAL_POSITION = 250;
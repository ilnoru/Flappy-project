import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyD8EXwz5GrOHHF4HgxR6_qlgGtGQeZS_Rw",
  authDomain: "flappy-bird-stackblitz.firebaseapp.com",
  projectId: "flappy-bird-stackblitz",
  storageBucket: "flappy-bird-stackblitz.appspot.com",
  messagingSenderId: "339876453212",
  appId: "1:339876453212:web:4b12345c678901d2345e67"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
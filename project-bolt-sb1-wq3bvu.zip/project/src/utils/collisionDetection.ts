import type { Pipe } from '../types/game';

interface BirdRect {
  left: number;
  right: number;
  top: number;
  bottom: number;
}

interface PipeRect {
  left: number;
  right: number;
  top: number;
  bottom: number;
}

export const checkCollision = (
  birdPosition: number,
  pipes: Pipe[],
  gapSize: number
): boolean => {
  return pipes.some((pipe) => {
    const birdRect: BirdRect = {
      left: 50,
      right: 82,
      top: birdPosition,
      bottom: birdPosition + 32,
    };

    const topPipeRect: PipeRect = {
      left: pipe.position,
      right: pipe.position + 64,
      top: 0,
      bottom: pipe.height,
    };

    const bottomPipeRect: PipeRect = {
      left: pipe.position,
      right: pipe.position + 64,
      top: pipe.height + gapSize,
      bottom: 500,
    };

    return (
      (birdRect.right > topPipeRect.left &&
        birdRect.left < topPipeRect.right &&
        birdRect.top < topPipeRect.bottom) ||
      (birdRect.right > bottomPipeRect.left &&
        birdRect.left < bottomPipeRect.right &&
        birdRect.bottom > bottomPipeRect.top)
    );
  });
};